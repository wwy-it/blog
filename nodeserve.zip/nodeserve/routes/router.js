var http = require('http');
var qs = require('querystring');
var express = require('express');

var router = express.Router();
router.count = 0;

// 接受路由转接
router.use('/*', (req, res) => {

    let path = req._parsedUrl.pathname;               //路径的获取
    let method = req.method;                          //请求方式的获取
    let Authorization = req.headers.Authorization;    //请求头信息获取
    let query = req.query;                            //get请求参数的获取
    let body = req.body;                              //post请求参数的获取
    query=qs.stringify(query);
    body =qs.stringify(body);

    console.log(req.headers)
 
    console.log("********************************************************************************************************************************");
    console.log(path);
    console.log("1*********************************************");
    console.log(method);
    console.log("2*********************************************");
    console.log(Authorization);
    console.log("3*********************************************");
    console.log(query);
    console.log("4*********************************************");
    console.log(body);
    console.log("5*********************************************");

    const options = {
        hostname: '39.106.184.170',
        port: 5998,
        // path: '/contractlist/selectContract?' + content,
        method:method,
        headers: {
            'Authorization': Authorization,
            // 'Content-Type': 'application/x-www-form-urlencoded',
            // 'Content-Length': Buffer.byteLength(postData)
        }
    };
    if (method=='GET') {
        options.path=path+"?"+query;
    }else if(method=='post'){
        options.path=path;
        options.headers[Content-Type]='application/x-www-form-urlencoded';
        options.headers[Content-Length]=body.length;
    }
    
    console.log(options);
    //agen_req(Authorization);
    agen_req();

    //把数据返回前端
    res.json({ "wangwenyu": "ssssss" })
});



//向java发起请求
function agen_req(Authorization) {
    console.log("进入");

    //这是需要提交的数据  
    var data = {
        level: "1",
        pageNo: 1,
        pageSize: 10
    };
    var content = qs.stringify(data);

    //请求配置
    var options = {
        hostname: '39.106.184.170',
        port: 5998,
        path: '/contractlist/selectContract?' + content,
        method: 'GET',
        headers: {
            'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI5MjgwNTg1OTNAcXEuY29tIiwidXNlcl9pZCI6MTE5LCJwaG9uZSI6IjE1MzEzMDAxMDYxIiwiaWRlbnRpdHkiOm51bGwsInNjb3BlIjoiUk9MRV9VU0VSIiwibmFtZSI6IjkyODA1ODU5M0BxcS5jb20iLCJleHAiOjE1NjA4MjE3MTAsImlhdCI6MTU2MDczNTMxMCwianRpIjoiZjc4YTgyYjktMTliNC00MzE3LWFjYjktYTUwZmQyMGI5MjlkIn0.0t4VvywMrbez1oNQMHoTt5pxdxnStpxFKikH_WSoHjU'
        }
    };
    var req = http.request(options, function (res) {
        // console.log('STATUS: ' + res.statusCode);
        // console.log('HEADERS: ' + JSON.stringify(res.headers));
        res.setEncoding('utf8');
        res.on('data', function (chunk) {
            console.log('BODY: ' + chunk);
        });
    });
    req.on('error', function (e) {
        console.log('problem with request: ' + e.message);
    });

    req.end();
}
module.exports = router;