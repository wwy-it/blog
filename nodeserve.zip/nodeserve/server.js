const fs = require('fs');
var https = require('https');
const path = require('path');

const express = require("express");
const bodyParser = require('body-parser');
var router = require('./routes/router');
const app = express();

const proxy = require('http-proxy-middleware');

var keyPath = '../ssl/other/6071791_aiq.group.key';
var certPath = '../ssl/other/6071791_aiq.group.pem';

var hskey = fs.readFileSync(keyPath);
var hscert = fs.readFileSync(certPath);

//解析 application/json
// app.use(bodyParser.json());

//解析 application/x-www-form-urlencoded
// app.use(bodyParser.urlencoded());

//设定静态文件目录
app.use(express.static(path.resolve(__dirname, './static')));
//对请求的接口进行路由转接；
app.use('/agent', router);

app.use('/api', proxy(
    {
        // target: "http://8.140.50.228:5000",//dev
        target: "http://47.94.221.159:5000",//demo
        changeOrigin: true,
        ws: true,
        pathRewrite: {
            "old-path": "new-path",
            "/api": ""
        },
    }
));

//请求任意路径时候返回index.html文件到客户端，保证客户端用到路由情况下的刷新不失效；
app.use('/', function (req, res) {
    const html = fs.readFileSync(path.resolve(__dirname, './static/index.html'), 'utf-8')
    res.send(html);
})

// https
var server = https.createServer({
    key: hskey,
    cert: hscert
}, app);

const port = 443
server.listen(port, function () {
    console.log(port + '端口启动')
});