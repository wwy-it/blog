// http-proxy-middleware版本1.0.5的时候默认导出的不是proxy的函数了，需要用以下注释的方式调用
// const { createProxyMiddleware: proxy } = require('http-proxy-middleware');

const fs = require('fs');
var https = require('https');
const path = require('path');

const express = require("express");
const bodyParser = require('body-parser');
var router = require('./routes/router');
const app = express();

const proxy = require('http-proxy-middleware');

const { port = 8000, proxy: proxyConfig = {} } = require('./serverConfig');

Object.keys(proxyConfig).map(key => {
    app.use(key, proxy(proxyConfig[key]));
})

var keyPath = '../ssl/other/6071791_aiq.group.key';
var certPath = '../ssl/other/6071791_aiq.group.pem';


var hskey = fs.readFileSync(keyPath);
var hscert = fs.readFileSync(certPath);


//解析 application/json
app.use(bodyParser.json());
//解析 application/x-www-form-urlencoded
app.use(bodyParser.urlencoded());

//设定静态文件目录
app.use(express.static(path.resolve(__dirname, './static')));
//对请求的接口进行路由转接；
app.use('/agent', router);
//请求任意路径时候返回index.html文件到客户端，保证客户端用到路由情况下的刷新不失效；
app.get('*', function (req, res) {
    const html = fs.readFileSync(path.resolve(__dirname, './static/index.html'), 'utf-8')
    res.send(html);
})

//设定服务器启动端口，开启前端项目；
// app.listen(5002, () => console.log("启动"));

// https
var server = https.createServer({
    key: hskey,
    cert: hscert
}, app);

server.listen(port, function () {
    console.log("5002端口启动")
    // console.log('runing Web Server in ' + port + ' port...');
});

